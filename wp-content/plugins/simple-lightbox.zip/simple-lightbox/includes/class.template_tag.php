<?php

/**
 * Template Tag
 * @package Simple Lightbox
 * @subpackage Template
 * @author Archetyped
 */
class SLB_Template_Tag extends SLB_Component { }